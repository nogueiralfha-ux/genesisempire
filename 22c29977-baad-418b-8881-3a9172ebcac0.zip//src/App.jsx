import React, { useState, useEffect } from "react";
// import { supabase } from './supabaseClient'; // MANTENHA ISTO NO SEU CODESANDBOX REAL
import {
  SplitSquareHorizontal,
  Users,
  Wind,
  Sparkles,
  Trophy,
  Clock,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Flame,
  Star,
  Target,
  Shield,
  Zap,
  ChevronRight,
  LayoutDashboard,
  BrainCircuit,
  Activity,
  Users2,
  LogOut,
  TrendingUp,
  AlertTriangle,
  TreePine,
  Share2,
  Copy,
  Lock,
  Crown,
  Gift,
  Sword,
  Footprints,
  Shirt,
  Circle,
  Sun,
  Skull,
  ShieldAlert,
  User,
  PieChart,
  BookOpen,
} from "lucide-react";

// --- MOCK DO SUPABASE PARA O AMBIENTE DE VISUALIZAÇÃO ---
// Lembre-se: APAGUE este bloco no seu CodeSandbox, tal como fez da última vez!
const supabase = {
  from: (table) => ({
    insert: async (data) => {
      console.log(`[Supabase Mock] Simulando inserção:`, data);
      return { data: data, error: null };
    },
  }),
};

// --- BANCO DE PERGUNTAS EXPANDIDO ---
const QUESTIONS = [
  {
    question:
      "No Princípio, qual foi o primeiro elemento a ser separado do Vazio?",
    options: [
      "A Água e a Terra",
      "A Luz e a Escuridão",
      "O Céu e o Mar",
      "A Fauna e a Flora",
    ],
    correct: 1,
    oracleHint:
      "Sem isto, haveria apenas trevas. É a energia fundamental da observação.",
    points: 1000,
  },
  {
    question:
      "Na simulação de Biomas, o que acontece a uma manada de herbívoros se houver escassez de flora?",
    options: [
      "Evoluem para carnívoros",
      "O Índice de Harmonia sobe",
      "Migram ou perecem",
      "Entram em hibernação",
    ],
    correct: 2,
    oracleHint:
      "A cadeia alimentar não perdoa. O movimento é a única resposta à falta de recursos base.",
    points: 2500,
  },
  {
    question: "Qual foi a responsabilidade taxonómica dada ao homem no Jardim?",
    options: [
      "Criar novas espécies",
      "Governar os anjos",
      "Nomear os animais",
      "Construir muralhas",
    ],
    correct: 2,
    oracleHint:
      "A linguagem e a classificação são as primeiras formas de ciência e cuidado ambiental.",
    points: 5000,
  },
  {
    question:
      "A Árvore do Conhecimento no centro do Éden representa qual conceito ético?",
    options: [
      "Imortalidade física",
      "Livre-Arbítrio e escolha moral",
      "Fonte de energia ilimitada",
      "Previsão do futuro",
    ],
    correct: 1,
    oracleHint:
      "A obediência não tem valor se não houver a liberdade para desobedecer.",
    points: 10000,
  },
  {
    question:
      "Se a barra de 'Harmonia Global' cair abaixo de 30%, o que ocorre no motor do jogo?",
    options: [
      "Os animais multiplicam-se",
      "As águas secam",
      "Ocorre decadência visual e fuga animal",
      "O jogo reinicia automaticamente",
    ],
    correct: 2,
    oracleHint:
      "O mundo reage à falta de equilíbrio perdendo a sua beleza e estabilidade natural.",
    points: 50000,
  },
];

// --- EXPANSÃO EFÉSIOS 6:10 (A ARMADURA DE DEUS) ---
const ARMOR_PIECES = [
  {
    id: "belt",
    name: "Cinto da Verdade",
    levelReq: 2,
    icon: Circle,
    verse: '"...cingindo os vossos lombos com a verdade..."',
  },
  {
    id: "breastplate",
    name: "Couraça da Justiça",
    levelReq: 5,
    icon: Shirt,
    verse: '"...e vestida a couraça da justiça."',
  },
  {
    id: "shoes",
    name: "Calçados da Paz",
    levelReq: 8,
    icon: Footprints,
    verse: '"...calçados os pés na preparação do evangelho da paz."',
  },
  {
    id: "shield",
    name: "Escudo da Fé",
    levelReq: 12,
    icon: Shield,
    verse: '"...tomando sobretudo o escudo da fé..."',
  },
  {
    id: "helmet",
    name: "Capacete da Salvação",
    levelReq: 16,
    icon: Sun,
    verse: '"Tomai também o capacete da salvação..."',
  },
  {
    id: "sword",
    name: "Espada do Espírito",
    levelReq: 20,
    icon: Sword,
    verse: '"...e a espada do Espírito, que é a palavra de Deus."',
  },
];

// --- COMPONENTE PRINCIPAL (SELETOR DE ROTAS) ---
export default function App() {
  const [role, setRole] = useState("select");

  if (role === "select") {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]">
        <div className="mb-12 text-center">
          <Globe2 className="w-16 h-16 text-amber-500 mx-auto mb-4 animate-pulse" />
          <h1 className="text-4xl font-black text-white tracking-widest uppercase">
            Genesis Empire
          </h1>
          <p className="text-slate-400 mt-2 font-mono">
            MVP Versão 1.8 - Inteligência B2B
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
          {/* Portal do Aluno */}
          <button
            onClick={() => setRole("student")}
            className="group relative bg-slate-900 border border-slate-800 p-8 rounded-3xl overflow-hidden hover:border-amber-500/50 transition-all text-left flex flex-col items-start shadow-xl"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 group-hover:bg-amber-500/20 transition-all"></div>
            <div className="w-16 h-16 bg-slate-950 rounded-2xl flex items-center justify-center border border-slate-800 mb-6 group-hover:scale-110 transition-transform">
              <Play className="w-8 h-8 text-amber-500" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">
              Portal do Aluno
            </h2>
            <p className="text-slate-400 text-sm">
              Aceda à Arena, forje a Armadura e derrote o Grande Dragão.
            </p>
          </button>

          {/* Portal do Professor */}
          <button
            onClick={() => setRole("teacher")}
            className="group relative bg-slate-900 border border-slate-800 p-8 rounded-3xl overflow-hidden hover:border-blue-500/50 transition-all text-left flex flex-col items-start shadow-xl"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 group-hover:bg-blue-500/20 transition-all"></div>
            <div className="w-16 h-16 bg-slate-950 rounded-2xl flex items-center justify-center border border-slate-800 mb-6 group-hover:scale-110 transition-transform">
              <LayoutDashboard className="w-8 h-8 text-blue-500" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">
              Centro B2B (Professor)
            </h2>
            <p className="text-slate-400 text-sm">
              Monitorize métricas ao vivo e gere relatórios de Inteligência
              Artificial.
            </p>
          </button>
        </div>
      </div>
    );
  }

  if (role === "student")
    return <StudentApp onLogout={() => setRole("select")} />;
  if (role === "teacher")
    return <TeacherDashboard onLogout={() => setRole("select")} />;

  return null;
}

// =========================================================================
// MÓDULO 1: PORTAL DO ALUNO
// =========================================================================
function StudentApp({ onLogout }) {
  const INITIAL_PROFILE = {
    name: "Aluno #104",
    level: 20,
    title: "Paladino do Espírito",
    xp: 15500,
    nextLevelXp: 16000,
    streak: 7,
    totalCoins: 124000,
    friendsInvited: 2,
  };

  const [gameState, setGameState] = useState("dashboard");
  const [activeTab, setActiveTab] = useState("arena");
  const [profile, setProfile] = useState(INITIAL_PROFILE);
  const [gameQuestions, setGameQuestions] = useState(QUESTIONS);
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(1);
  const [timeLeft, setTimeLeft] = useState(30);
  const [isTimerPaused, setIsTimerPaused] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
  const [isRevealed, setIsRevealed] = useState(false);
  const [usedLifelines, setUsedLifelines] = useState({
    fiftyFifty: false,
    audience: false,
    skip: false,
    oracle: false,
  });
  const [eliminatedOptions, setEliminatedOptions] = useState([]);
  const [activeModal, setActiveModal] = useState(null);
  const [audienceData, setAudienceData] = useState([]);

  const currentQ = gameQuestions[currentQIndex];

  useEffect(() => {
    if (gameState !== "playing" || isTimerPaused || isRevealed) return;
    if (timeLeft <= 0) {
      handleGameOver(score);
      return;
    }
    const timer = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, gameState, isTimerPaused, isRevealed, score]);

  const handleGameOver = async (finalScore) => {
    setGameState("gameover");
    const earnedXp = Math.floor(finalScore * 0.1);
    setProfile((prev) => ({
      ...prev,
      totalCoins: prev.totalCoins + finalScore,
      xp: prev.xp + earnedXp,
      level:
        prev.xp + earnedXp >= prev.nextLevelXp ? prev.level + 1 : prev.level,
      nextLevelXp:
        prev.xp + earnedXp >= prev.nextLevelXp
          ? prev.nextLevelXp + 2000
          : prev.nextLevelXp,
    }));
    try {
      await supabase
        .from("quiz_results")
        .insert([{ score: finalScore, correct_answers: currentQIndex }]);
    } catch (error) {}
  };

  const handleCorrectAnswer = () => {
    const timeBonus = timeLeft > 15 ? 1.5 : 1;
    const earnedPoints = Math.floor(currentQ.points * timeBonus * combo);
    setScore((prev) => prev + earnedPoints);
    setCombo((prev) => (prev < 5 ? prev + 1 : 5));

    if (currentQIndex === gameQuestions.length - 1) {
      setGameState("victory");
      handleGameOver(score + earnedPoints);
    } else {
      setCurrentQIndex((prev) => prev + 1);
      resetTurn();
    }
  };

  const handleOptionSelect = (index) => {
    if (selectedOption !== null || isRevealed) return;
    setSelectedOption(index);
    setIsTimerPaused(true);
    setTimeout(() => {
      setIsRevealed(true);
      setTimeout(() => {
        if (index === currentQ.correct) handleCorrectAnswer();
        else {
          setCombo(1);
          handleGameOver(score);
        }
      }, 3000);
    }, 2000);
  };

  const resetTurn = () => {
    setSelectedOption(null);
    setIsRevealed(false);
    setTimeLeft(30);
    setIsTimerPaused(false);
    setEliminatedOptions([]);
    setActiveModal(null);
  };

  const startGame = () => {
    const shuffledQuestions = [...QUESTIONS].sort(() => Math.random() - 0.5);
    setGameQuestions(shuffledQuestions);
    setGameState("playing");
    setCurrentQIndex(0);
    setScore(0);
    setCombo(1);
    setUsedLifelines({
      fiftyFifty: false,
      audience: false,
      skip: false,
      oracle: false,
    });
    resetTurn();
  };

  const useFiftyFifty = () => {
    if (usedLifelines.fiftyFifty) return;
    let wrong = [0, 1, 2, 3]
      .filter((i) => i !== currentQ.correct)
      .sort(() => 0.5 - Math.random())
      .slice(0, 2);
    setEliminatedOptions(wrong);
    setUsedLifelines((p) => ({ ...p, fiftyFifty: true }));
  };
  const useAudience = () => {
    if (usedLifelines.audience) return;
    setIsTimerPaused(true);
    let data = [0, 0, 0, 0],
      rem = 100;
    const corr = Math.floor(Math.random() * 30) + 40;
    data[currentQ.correct] = corr;
    rem -= corr;
    [0, 1, 2, 3]
      .filter((i) => i !== currentQ.correct && !eliminatedOptions.includes(i))
      .forEach((idx, i, arr) => {
        if (i === arr.length - 1) data[idx] = rem;
        else {
          const s = Math.floor(Math.random() * (rem - 5));
          data[idx] = s;
          rem -= s;
        }
      });
    setAudienceData(data);
    setActiveModal("audience");
    setUsedLifelines((p) => ({ ...p, audience: true }));
  };
  const useOracle = () => {
    if (usedLifelines.oracle) return;
    setIsTimerPaused(true);
    setActiveModal("oracle");
    setUsedLifelines((p) => ({ ...p, oracle: true }));
  };
  const useSkip = () => {
    if (usedLifelines.skip) return;
    setUsedLifelines((p) => ({ ...p, skip: true }));
    if (currentQIndex === gameQuestions.length - 1) {
      setGameState("victory");
      handleGameOver(score);
    } else {
      setCurrentQIndex((p) => p + 1);
      resetTurn();
    }
  };
  const closeModal = () => {
    setActiveModal(null);
    setIsTimerPaused(false);
  };
  const copyInviteLink = () => alert("Link copiado!");

  if (gameState === "boss_fight") {
    return (
      <BossFight
        onWin={() => setGameState("victory_dragon")}
        onFlee={() => setGameState("dashboard")}
      />
    );
  }

  if (gameState === "victory_dragon") {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-yellow-900/40 via-slate-950 to-black"></div>
        <div className="w-40 h-40 bg-gradient-to-br from-yellow-300 to-amber-600 rounded-full flex items-center justify-center shadow-[0_0_100px_rgba(252,211,77,0.8)] mb-8 animate-pulse relative z-10">
          <Crown className="w-20 h-20 text-slate-950" />
        </div>
        <h1 className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 to-amber-600 mb-4 tracking-widest text-center relative z-10">
          O MAL FOI ANIQUILADO
        </h1>
        <p className="text-xl text-amber-100/80 mb-12 text-center max-w-2xl relative z-10 italic">
          O Grande Dragão caiu perante a Luz. Tu provaste ser um verdadeiro
          Arquiteto Divino, vestido com a armadura completa. A harmonia foi
          restaurada no Éden.
        </p>
        <button
          onClick={() => setGameState("dashboard")}
          className="relative z-10 px-10 py-5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-full font-black text-xl transition-all shadow-[0_0_30px_rgba(245,158,11,0.5)]"
        >
          Voltar ao Império em Paz
        </button>
      </div>
    );
  }

  if (gameState === "dashboard") {
    return (
      <div className="min-h-screen bg-slate-950 p-4 md:p-8 flex items-center justify-center font-sans text-slate-200 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] relative overflow-y-auto">
        <button
          onClick={onLogout}
          className="absolute top-6 left-6 flex items-center text-slate-500 hover:text-white transition-colors z-50"
        >
          <LogOut className="w-5 h-5 mr-2" /> Sair
        </button>

        <div className="max-w-6xl w-full pt-16 pb-12">
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <button
              onClick={() => setActiveTab("arena")}
              className={`px-6 py-3 rounded-full font-bold flex items-center transition-all ${
                activeTab === "arena"
                  ? "bg-amber-500 text-slate-950 shadow-[0_0_20px_rgba(245,158,11,0.4)]"
                  : "bg-slate-900 text-slate-400 border border-slate-800 hover:text-white"
              }`}
            >
              <Trophy className="w-5 h-5 mr-2" /> Arena
            </button>
            <button
              onClick={() => setActiveTab("armadura")}
              className={`px-6 py-3 rounded-full font-bold flex items-center transition-all ${
                activeTab === "armadura"
                  ? "bg-indigo-500 text-white shadow-[0_0_20px_rgba(99,102,241,0.4)]"
                  : "bg-slate-900 text-slate-400 border border-slate-800 hover:text-white"
              }`}
            >
              <Shield className="w-5 h-5 mr-2" /> Arsenal de Éfeso
            </button>
            <button
              onClick={() => setActiveTab("semeadores")}
              className={`px-6 py-3 rounded-full font-bold flex items-center transition-all ${
                activeTab === "semeadores"
                  ? "bg-green-500 text-slate-950 shadow-[0_0_20px_rgba(34,197,94,0.4)]"
                  : "bg-slate-900 text-slate-400 border border-slate-800 hover:text-white"
              }`}
            >
              <TreePine className="w-5 h-5 mr-2" /> Semeadores
            </button>
          </div>

          {activeTab === "arena" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-1 space-y-6">
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-500 to-yellow-300"></div>
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center border-2 border-amber-500/50 relative">
                      <Shield className="w-8 h-8 text-amber-500" />
                      <div className="absolute -bottom-2 -right-2 bg-indigo-600 text-white text-xs font-black px-2 py-0.5 rounded-full border-2 border-slate-900">
                        Nv {profile.level}
                      </div>
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-white">
                        {profile.name}
                      </h2>
                      <p className="text-amber-500 text-sm font-semibold">
                        {profile.title}
                      </p>
                    </div>
                  </div>
                  <div className="space-y-2 mb-6">
                    <div className="flex justify-between text-xs font-bold text-slate-400">
                      <span>Próximo Nível</span>
                      <span>
                        {profile.xp} / {profile.nextLevelXp} XP
                      </span>
                    </div>
                    <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                      <div
                        className="h-full bg-gradient-to-r from-amber-600 to-yellow-400"
                        style={{
                          width: `${(profile.xp / profile.nextLevelXp) * 100}%`,
                        }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="md:col-span-2 flex flex-col space-y-6">
                <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-8 shadow-[0_0_40px_rgba(245,158,11,0.2)] relative overflow-hidden flex flex-col justify-center h-full min-h-[300px]">
                  <div className="relative z-10">
                    <h1 className="text-4xl md:text-5xl font-black text-white mb-4 leading-tight">
                      ARENA DO CONHECIMENTO
                    </h1>
                    <p className="text-amber-100 mb-8 max-w-md text-lg">
                      Acumule XP para forjar a Armadura de Deus.
                    </p>
                    <button
                      onClick={startGame}
                      className="group flex items-center bg-slate-950 text-white px-8 py-4 rounded-full font-bold text-lg hover:scale-105 transition-all"
                    >
                      <Play className="w-5 h-5 mr-3 fill-amber-500 text-amber-500" />{" "}
                      INICIAR DESAFIO DIÁRIO
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "armadura" && (
            <div className="space-y-8 animate-in fade-in zoom-in duration-500">
              <div className="text-center max-w-3xl mx-auto mb-8">
                <h2 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 via-purple-300 to-indigo-300 mb-4 tracking-widest uppercase">
                  A Forja do Paladino
                </h2>
                <p className="text-slate-400 text-lg italic font-serif">
                  "Revesti-vos de toda a armadura de Deus..." — Efésios 6:11
                </p>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <div className="lg:col-span-5">
                  <HolographicPaladin level={profile.level} />
                </div>
                <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-2 gap-4">
                  {ARMOR_PIECES.map((piece, idx) => {
                    const isUnlocked = profile.level >= piece.levelReq;
                    const Icon = piece.icon;
                    return (
                      <div
                        key={idx}
                        className={`relative p-5 rounded-2xl border-2 flex items-center transition-all duration-500 ${
                          isUnlocked
                            ? "bg-slate-900 border-indigo-500/50 shadow-[0_0_20px_rgba(99,102,241,0.15)]"
                            : "bg-slate-950 border-slate-800 opacity-60 grayscale"
                        }`}
                      >
                        {isUnlocked && (
                          <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/10 to-transparent opacity-50"></div>
                        )}
                        <div
                          className={`w-14 h-14 rounded-full flex items-center justify-center mr-4 border-2 shrink-0 relative z-10 ${
                            isUnlocked
                              ? "bg-indigo-950 border-indigo-400 shadow-[0_0_15px_rgba(129,140,248,0.5)]"
                              : "bg-slate-900 border-slate-700"
                          }`}
                        >
                          {isUnlocked ? (
                            <Icon className="w-7 h-7 text-indigo-300" />
                          ) : (
                            <Lock className="w-5 h-5 text-slate-500" />
                          )}
                        </div>
                        <div className="relative z-10 flex-1">
                          <h3
                            className={`font-black text-sm mb-1 ${
                              isUnlocked ? "text-white" : "text-slate-500"
                            }`}
                          >
                            {piece.name}
                          </h3>
                          {isUnlocked ? (
                            <p className="text-[10px] italic text-indigo-200/70 leading-tight">
                              {piece.verse}
                            </p>
                          ) : (
                            <span className="inline-block px-2 py-0.5 bg-slate-900 text-slate-500 text-[10px] font-black uppercase tracking-widest rounded-full border border-slate-800 mt-1">
                              Desbloqueia Nv. {piece.levelReq}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* COVIL DO DRAGÃO */}
              <div className="mt-12 relative rounded-3xl overflow-hidden border-2 border-red-900/50 shadow-[0_0_50px_rgba(220,38,38,0.1)]">
                <div className="absolute inset-0 bg-gradient-to-br from-red-950 via-slate-950 to-orange-950"></div>
                <div className="relative z-10 p-8 md:p-12 flex flex-col md:flex-row items-center justify-between">
                  <div className="mb-6 md:mb-0 md:mr-8 text-center md:text-left flex-1">
                    <div className="inline-flex items-center space-x-2 bg-red-950/50 border border-red-500/30 px-3 py-1 rounded-full mb-4">
                      <Flame className="w-4 h-4 text-orange-500 animate-pulse" />
                      <span className="text-xs font-bold text-red-400 uppercase tracking-widest">
                        Apocalipse 12
                      </span>
                    </div>
                    <h2 className="text-3xl md:text-5xl font-black text-white mb-4 drop-shadow-[0_0_15px_rgba(220,38,38,0.8)]">
                      O GRANDE DRAGÃO VERMELHO
                    </h2>
                    <p className="text-red-200/80 text-lg max-w-xl">
                      A Antiga Serpente aguarda. Apenas um Arquiteto com a
                      armadura completa resistirá ao seu fogo.
                    </p>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-32 h-32 rounded-full border-4 border-red-900 bg-red-950 flex items-center justify-center relative shadow-[0_0_50px_rgba(220,38,38,0.4)] mb-6">
                      <Skull className="w-16 h-16 text-red-500 animate-pulse" />
                      {profile.level < 20 && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/60 rounded-full">
                          <Lock className="w-10 h-10 text-slate-400" />
                        </div>
                      )}
                    </div>
                    {profile.level >= 20 ? (
                      <button
                        onClick={() => setGameState("boss_fight")}
                        className="px-8 py-4 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white font-black text-lg rounded-full shadow-[0_0_30px_rgba(220,38,38,0.6)] hover:scale-105 transition-all flex items-center uppercase tracking-wider"
                      >
                        <Sword className="w-6 h-6 mr-3" /> Enfrentar a Besta
                      </button>
                    ) : (
                      <div className="text-center">
                        <button
                          disabled
                          className="px-8 py-4 bg-slate-900 border border-slate-800 text-slate-500 font-black text-lg rounded-full cursor-not-allowed uppercase tracking-wider"
                        >
                          Covil Selado
                        </button>
                        <p className="text-xs text-red-400 mt-3 font-bold uppercase tracking-widest">
                          Requer Nível 20
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "semeadores" && (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
              <div className="max-w-3xl mx-auto text-center mb-10">
                <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6 border-2 border-green-500/30">
                  <TreePine className="w-10 h-10 text-green-400" />
                </div>
                <h2 className="text-3xl font-black text-white mb-4">
                  A Sua Árvore de Influência
                </h2>
                <button
                  onClick={copyInviteLink}
                  className="mt-4 px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-all inline-flex"
                >
                  <Copy className="w-5 h-5 mr-2" /> Copiar Link de Semeador
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (gameState === "playing") {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-200 p-4 md:p-8 flex flex-col relative z-10">
        <div className="flex justify-between items-center mb-8">
          <div className="text-2xl font-black font-mono">{timeLeft}s</div>
          <div className="text-right font-black text-amber-400">
            {score.toLocaleString()} M
          </div>
        </div>
        <div className="flex-1 flex flex-col justify-center mb-8">
          <div className="bg-slate-900 border-2 border-slate-800 p-8 rounded-3xl">
            <h2 className="text-2xl font-semibold text-center">
              {currentQ?.question}
            </h2>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentQ?.options.map((opt, idx) => (
            <button
              key={idx}
              onClick={() => handleOptionSelect(idx)}
              className="p-6 rounded-2xl border-2 border-slate-700 bg-slate-800 hover:bg-slate-700 text-left"
            >
              {opt}
            </button>
          ))}
        </div>
        <button
          onClick={() => setGameState("dashboard")}
          className="mt-8 mx-auto w-40 text-center text-slate-500"
        >
          Sair
        </button>
      </div>
    );
  }
}

function HolographicPaladin({ level }) {
  const pieces = {
    belt: level >= 2,
    breastplate: level >= 5,
    shoes: level >= 8,
    shield: level >= 12,
    helmet: level >= 16,
    sword: level >= 20,
  };
  return (
    <div className="relative w-full max-w-sm mx-auto aspect-[3/4] bg-slate-950 border-2 border-indigo-500/30 rounded-3xl overflow-hidden shadow-[inset_0_0_60px_rgba(79,70,229,0.15)] flex flex-col items-center justify-center">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(99,102,241,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(99,102,241,0.1)_1px,transparent_1px)] bg-[size:20px_20px] opacity-60"></div>
      <div className="absolute top-0 left-0 w-full h-1 bg-indigo-400 shadow-[0_0_20px_rgba(99,102,241,1)] animate-[scan_4s_ease-in-out_infinite]"></div>
      <div className="absolute inset-0 flex items-center justify-center opacity-10">
        <User className="w-56 h-72 text-indigo-200" strokeWidth={1} />
      </div>
      <div className="relative w-full h-full pointer-events-none">
        <div
          className={`absolute top-[12%] left-1/2 -translate-x-1/2 transition-all duration-1000 ease-out flex flex-col items-center ${
            pieces.helmet
              ? "opacity-100 scale-100 drop-shadow-[0_0_25px_rgba(250,204,21,0.9)] translate-y-0"
              : "opacity-0 scale-150 -translate-y-20"
          }`}
        >
          <Sun className="w-20 h-20 text-yellow-400" />
        </div>
        <div
          className={`absolute top-[32%] left-1/2 -translate-x-1/2 transition-all duration-1000 delay-100 ease-out ${
            pieces.breastplate
              ? "opacity-100 scale-100 drop-shadow-[0_0_25px_rgba(167,139,250,0.9)] translate-y-0"
              : "opacity-0 scale-50 translate-y-10"
          }`}
        >
          <Shirt
            className="w-32 h-32 text-indigo-300 fill-indigo-900/50"
            strokeWidth={1.5}
          />
        </div>
        <div
          className={`absolute top-[58%] left-1/2 -translate-x-1/2 transition-all duration-1000 delay-200 ease-out ${
            pieces.belt
              ? "opacity-100 scale-100 drop-shadow-[0_0_25px_rgba(249,115,22,0.9)] translate-y-0"
              : "opacity-0 scale-150 translate-y-10"
          }`}
        >
          <Circle className="w-16 h-16 text-orange-400" strokeWidth={3} />
        </div>
        <div
          className={`absolute bottom-[8%] left-1/2 -translate-x-1/2 transition-all duration-1000 delay-300 ease-out ${
            pieces.shoes
              ? "opacity-100 scale-100 drop-shadow-[0_0_25px_rgba(148,163,184,0.9)] translate-y-0"
              : "opacity-0 scale-50 translate-y-20"
          }`}
        >
          <Footprints className="w-20 h-20 text-slate-300" />
        </div>
        <div
          className={`absolute top-[40%] left-[10%] transition-all duration-1000 delay-500 ease-out ${
            pieces.shield
              ? "opacity-100 scale-100 drop-shadow-[0_0_35px_rgba(56,189,248,0.9)] translate-x-0"
              : "opacity-0 scale-50 -translate-x-20"
          }`}
        >
          <Shield
            className="w-24 h-24 text-sky-400 fill-sky-950/80"
            strokeWidth={1.5}
          />
        </div>
        <div
          className={`absolute top-[35%] right-[10%] transition-all duration-1000 delay-700 ease-out ${
            pieces.sword
              ? "opacity-100 scale-100 drop-shadow-[0_0_35px_rgba(239,68,68,0.9)] translate-x-0 rotate-[15deg]"
              : "opacity-0 scale-50 translate-x-20 -rotate-45"
          }`}
        >
          <Sword className="w-28 h-28 text-red-500" strokeWidth={1.5} />
        </div>
      </div>
      <div className="absolute bottom-4 left-4 right-4 flex justify-between text-xs font-mono text-indigo-300/70 border-t border-indigo-500/30 pt-2 z-10">
        <span>SISTEMA: {level >= 20 ? "PRONTO" : "FORJANDO"}</span>
        <span className="flex items-center">
          <Star className="w-3 h-3 mr-1" /> NÍVEL {level}
        </span>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `@keyframes scan { 0% { top: 0%; opacity: 0; } 10% { opacity: 1; } 90% { opacity: 1; } 100% { top: 100%; opacity: 0; } }`,
        }}
      />
    </div>
  );
}

function BossFight({ onWin, onFlee }) {
  const [dragonHp, setDragonHp] = useState(2000);
  const [playerHp, setPlayerHp] = useState(500);
  const [dragonStatus, setDragonStatus] = useState("normal");
  const [log, setLog] = useState(
    "O Grande Dragão Vermelho surge do abismo. As sete cabeças rugem!"
  );
  const [combatPhase, setCombatPhase] = useState("fighting");
  const [shake, setShake] = useState(false);
  const [fireAttack, setFireAttack] = useState(false);
  const [shieldFlash, setShieldFlash] = useState(false);

  useEffect(() => {
    if (combatPhase !== "fighting") return;
    const attackTimer = setInterval(() => {
      if (dragonStatus !== "stunned") {
        setShake(true);
        setPlayerHp((prev) => Math.max(0, prev - 45));
        setLog(
          "🔥 O Dragão cospe chamas infernais! A tua armadura resiste, mas sofres dano! (-45 HP)"
        );
        setTimeout(() => setShake(false), 500);
        if (playerHp <= 45) {
          alert("Foste derrotado... O Éden caiu. (Voltando ao Hub)");
          onFlee();
        }
      }
    }, 3000);
    return () => clearInterval(attackTimer);
  }, [dragonStatus, combatPhase, playerHp, onFlee]);

  const useShield = () => {
    if (combatPhase !== "fighting") return;
    setShieldFlash(true);
    setDragonStatus("stunned");
    setLog(
      "✨ Levantaste o Escudo da Fé! Uma luz ofuscante cega as bestas do dragão. Ele está perdido!"
    );
    setTimeout(() => setShieldFlash(false), 800);
    setTimeout(() => {
      if (dragonHp > 0) {
        setDragonStatus("normal");
        setLog("O Dragão recupera a visão e ruge de fúria!");
      }
    }, 4000);
  };

  const useSword = () => {
    if (combatPhase !== "fighting") return;
    setFireAttack(true);
    setTimeout(() => setFireAttack(false), 400);
    const isCritical = dragonStatus === "stunned";
    const damage = isCritical ? 250 : 80;
    const newHp = Math.max(0, dragonHp - damage);
    setDragonHp(newHp);
    if (isCritical) {
      setLog(
        `⚔️ CRÍTICO! A Espada lança labaredas sagradas no Dragão cego! (-${damage} HP)`
      );
    } else {
      setLog(
        `⚔️ A tua espada rasga as escamas, mas o Dragão defende-se! (-${damage} HP)`
      );
    }
    if (newHp <= 0) {
      setCombatPhase("final_blow");
      setLog("O Dragão cai de joelhos... É a hora do golpe final!");
    }
  };

  if (combatPhase === "final_blow") {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-8 relative overflow-hidden transition-all duration-1000">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-yellow-500/20 to-black animate-pulse"></div>
        <button
          onClick={() => setTimeout(() => onWin(), 3000)}
          className="group relative px-12 py-8 bg-transparent overflow-hidden rounded-full border-4 border-amber-400 hover:bg-amber-400/10 transition-all z-10"
        >
          <div className="absolute inset-0 bg-white/20 blur-xl scale-0 group-hover:scale-150 transition-all duration-700"></div>
          <h2 className="text-3xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-400 to-red-500 uppercase tracking-widest text-center">
            "Por Jeová, e seu Filho Jesus Cristo,
            <br /> pelo poder do Espírito Santo!"
          </h2>
        </button>
      </div>
    );
  }

  return (
    <div
      className={`min-h-screen flex flex-col p-4 md:p-8 relative overflow-hidden transition-all duration-300 ${
        shake
          ? "bg-red-950 translate-x-2"
          : shieldFlash
          ? "bg-indigo-950"
          : "bg-slate-950"
      }`}
    >
      <div className="absolute inset-0 opacity-40 bg-[url('https://www.transparenttextures.com/patterns/black-scales.png')] pointer-events-none"></div>
      <div className="flex justify-between items-center z-10 w-full max-w-4xl mx-auto mb-8">
        <button
          onClick={onFlee}
          className="text-slate-500 hover:text-white font-bold uppercase text-sm border border-slate-800 px-4 py-2 rounded-lg"
        >
          Fugir
        </button>
        <span className="text-red-500 font-black tracking-widest uppercase animate-pulse">
          Combate Ativo
        </span>
      </div>
      <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full z-10">
        <div className="flex flex-col items-center mb-8">
          <div className="w-full max-w-lg mb-4">
            <div className="flex justify-between text-red-400 font-bold mb-1 text-sm uppercase">
              <span>Grande Dragão Vermelho</span>
              <span>{dragonHp} / 2000 HP</span>
            </div>
            <div className="h-4 w-full bg-slate-900 rounded-full overflow-hidden border border-red-900">
              <div
                className="h-full bg-gradient-to-r from-red-800 to-red-500 transition-all duration-300"
                style={{ width: `${(dragonHp / 2000) * 100}%` }}
              ></div>
            </div>
          </div>
          <div
            className={`relative transition-all duration-700 ${
              dragonStatus === "stunned"
                ? "grayscale opacity-60 blur-[2px] scale-95"
                : "scale-100"
            }`}
          >
            <div
              className={`w-48 h-48 rounded-full border-4 flex items-center justify-center relative shadow-[0_0_80px_rgba(220,38,38,0.5)] bg-slate-950 ${
                dragonStatus === "stunned"
                  ? "border-slate-500"
                  : "border-red-600"
              }`}
            >
              <Skull
                className={`w-24 h-24 ${
                  dragonStatus === "stunned" ? "text-slate-500" : "text-red-500"
                }`}
              />
            </div>
            {dragonStatus === "stunned" && (
              <div className="absolute -top-4 -right-4 bg-indigo-600 text-white px-3 py-1 font-black uppercase tracking-widest text-xs rounded-full border-2 border-slate-900 animate-bounce">
                CEGO & PERDIDO!
              </div>
            )}
          </div>
        </div>
        <div className="bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-2xl p-6 text-center h-24 flex items-center justify-center shadow-lg mb-auto">
          <p className="text-lg md:text-xl font-medium text-slate-300 italic">
            "{log}"
          </p>
        </div>
        <div className="mt-8 flex flex-col md:flex-row items-center justify-between bg-slate-900 border-t-2 border-slate-800 p-6 rounded-3xl shadow-2xl relative overflow-hidden">
          {fireAttack && (
            <div className="absolute inset-0 bg-gradient-to-t from-orange-600/40 to-transparent"></div>
          )}
          {shieldFlash && (
            <div className="absolute inset-0 bg-gradient-to-t from-white/40 to-transparent"></div>
          )}
          <div className="w-full md:w-1/3 mb-6 md:mb-0 relative z-10">
            <div className="flex justify-between text-indigo-400 font-bold mb-1 text-sm uppercase">
              <span>A Sua Vida</span>
              <span>{playerHp} / 500 HP</span>
            </div>
            <div className="h-4 w-full bg-slate-950 rounded-full overflow-hidden border border-indigo-900">
              <div
                className="h-full bg-indigo-500 transition-all duration-300"
                style={{ width: `${(playerHp / 500) * 100}%` }}
              ></div>
            </div>
          </div>
          <div className="flex space-x-4 relative z-10">
            <button
              onClick={useShield}
              disabled={dragonStatus === "stunned"}
              className="flex flex-col items-center justify-center w-24 h-24 bg-slate-950 border-2 border-indigo-500/50 hover:bg-indigo-900/50 hover:border-indigo-400 rounded-2xl transition-all shadow-[0_0_20px_rgba(99,102,241,0.2)] disabled:opacity-30 disabled:cursor-not-allowed group"
            >
              <ShieldAlert className="w-8 h-8 text-indigo-300 mb-2 group-hover:text-white" />
              <span className="text-[10px] font-black uppercase text-indigo-300">
                Escudo da Fé
              </span>
            </button>
            <button
              onClick={useSword}
              className="flex flex-col items-center justify-center w-24 h-24 bg-slate-950 border-2 border-orange-500/50 hover:bg-orange-900/50 hover:border-orange-400 rounded-2xl transition-all shadow-[0_0_20px_rgba(249,115,22,0.2)] group relative overflow-hidden"
            >
              <Sword className="w-8 h-8 text-orange-400 mb-2 relative z-10 group-hover:text-yellow-300 group-hover:animate-pulse" />
              <span className="text-[10px] font-black uppercase text-orange-400 relative z-10">
                Espada do Fogo
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// =========================================================================
// MÓDULO 2: CENTRO B2B (DASHBOARD DO PROFESSOR REFORMULADO E PREMIUM)
// =========================================================================
function TeacherDashboard({ onLogout }) {
  const classMetrics = {
    harmonyAvg: 82,
    ethicsScore: 94,
    activeStudents: 28,
    totalStudents: 30,
  };

  // Lista de estudantes (1 Desbloqueado como amostra, resto bloqueado pelo Paywall)
  const studentInsights = [
    {
      id: 1,
      name: "Maria Clara",
      status: "Excelente",
      insight:
        "Alto nível de empatia ecológica. Liderança natural demonstrada no dilema da Árvore.",
      score: 98,
      locked: false,
    },
    {
      id: 2,
      name: "João Pedro",
      status: "Em Risco",
      insight: "Acesso restrito. Requer plano Arquiteto Divino.",
      score: 65,
      locked: true,
    },
    {
      id: 3,
      name: "Lucas Silva",
      status: "Regular",
      insight: "Acesso restrito. Requer plano Arquiteto Divino.",
      score: 78,
      locked: true,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans flex">
      {/* Sidebar B2B */}
      <div className="w-20 md:w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between p-4 transition-all z-20">
        <div>
          <div className="flex items-center justify-center md:justify-start space-x-3 mb-12 mt-2 px-2">
            <Globe2 className="w-8 h-8 text-blue-500" />
            <span className="hidden md:block font-black text-xl tracking-widest uppercase text-white">
              Genesis B2B
            </span>
          </div>
          <nav className="space-y-4">
            <SidebarLink icon={LayoutDashboard} label="Visão Geral" active />
            <SidebarLink icon={Users2} label="A Minha Turma" />
            <SidebarLink icon={BrainCircuit} label="Oráculo IA" isPremium />
            <SidebarLink icon={TrendingUp} label="Relatórios" />
          </nav>
        </div>
        <button
          onClick={onLogout}
          className="flex items-center justify-center md:justify-start space-x-3 px-4 py-3 text-slate-500 hover:text-white transition-colors rounded-xl hover:bg-slate-800"
        >
          <LogOut className="w-5 h-5" />
          <span className="hidden md:block font-semibold">Sair da Conta</span>
        </button>
      </div>

      {/* Conteúdo Principal */}
      <div className="flex-1 p-6 md:p-10 overflow-y-auto bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] relative">
        <header className="flex justify-between items-center mb-10">
          <div>
            <h1 className="text-3xl font-black text-white">
              Turma: 8º Ano - Ética e Natureza
            </h1>
            <p className="text-slate-400 mt-1">
              Colégio Santa Maria (Plano: Jardim do Éden)
            </p>
          </div>
          <div className="hidden md:flex items-center space-x-4 bg-slate-900 border border-slate-800 rounded-full px-4 py-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
            </span>
            <span className="text-sm font-bold text-slate-300">
              Telemetria Real-Time Ativa
            </span>
          </div>
        </header>

        {/* KPIs Principais */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <KPICard
            title="Média de Ética (Turma)"
            value={`${classMetrics.ethicsScore}%`}
            icon={BrainCircuit}
            color="text-purple-400"
            bg="bg-purple-500/10"
            border="border-purple-500/20"
          />
          <KPICard
            title="Harmonia Global (Ecossistema)"
            value={`${classMetrics.harmonyAvg}%`}
            icon={Globe2}
            color="text-blue-400"
            bg="bg-blue-500/10"
            border="border-blue-500/20"
          />
          <KPICard
            title="Alunos Ativos Agora"
            value={`${classMetrics.activeStudents} / ${classMetrics.totalStudents}`}
            icon={Users2}
            color="text-green-400"
            bg="bg-green-500/10"
            border="border-green-500/20"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* SECÇÃO: MATRIZ COGNITIVA DA TURMA */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-xl">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-white flex items-center">
                <PieChart className="w-6 h-6 mr-3 text-blue-500" /> Matriz
                Cognitiva e Moral
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* As Barras de Skill */}
              <div className="space-y-6">
                <SkillBar
                  label="Empatia Ecológica"
                  percentage={85}
                  color="bg-green-500"
                  icon={TreePine}
                />
                <SkillBar
                  label="Rigor Teológico"
                  percentage={92}
                  color="bg-amber-500"
                  icon={BookOpen}
                />
                <SkillBar
                  label="Lógica e Estratégia"
                  percentage={65}
                  color="bg-purple-500"
                  icon={BrainCircuit}
                />
                <SkillBar
                  label="Resiliência Ética"
                  percentage={78}
                  color="bg-blue-500"
                  icon={Shield}
                />
              </div>

              {/* A caixa de Insights Gerados por IA */}
              <div className="bg-blue-950/30 border border-blue-500/30 rounded-2xl p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
                <div className="flex items-center mb-4">
                  <Sparkles className="w-6 h-6 text-amber-400 mr-2 animate-pulse" />
                  <h3 className="font-bold text-blue-300 uppercase tracking-widest text-sm">
                    Oráculo Pedagógico AI
                  </h3>
                </div>
                <p className="text-slate-300 text-sm leading-relaxed mb-4">
                  "O modelo AWS SageMaker detetou que{" "}
                  <span className="text-white font-bold">35% da turma</span>{" "}
                  apresenta dificuldades na métrica de 'Lógica e Estratégia'
                  durante o Capítulo 3 (Biomas). Eles tendem a sacrificar a
                  Flora para salvar predadores a curto prazo."
                </p>
                <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
                  <span className="text-xs font-bold text-amber-500 uppercase block mb-1">
                    💡 Plano de Aula Recomendado:
                  </span>
                  <span className="text-sm text-slate-300 italic">
                    Debater Gênesis 2:15. Focar a próxima aula no conceito de
                    interdependência e gestão de recursos a longo prazo.
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Feed Lateral em Tempo Real */}
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col">
            <h2 className="text-xl font-bold text-white flex items-center mb-6">
              <Activity className="w-5 h-5 mr-2 text-green-500" /> Atividade ao
              Vivo
            </h2>
            <div className="flex-1 space-y-4 relative">
              <div className="absolute left-[11px] top-2 bottom-2 w-0.5 bg-slate-800"></div>

              <div className="relative pl-8">
                <div className="absolute left-0 top-1 w-6 h-6 rounded-full flex items-center justify-center border-4 border-slate-900 bg-red-500"></div>
                <p className="text-xs text-slate-500 font-mono mb-1">
                  AGORA • João Pedro
                </p>
                <p className="text-sm text-red-300">
                  Desequilíbrio crítico no Bioma Deserto. Causa: Falta de Água.
                </p>
              </div>
              <div className="relative pl-8">
                <div className="absolute left-0 top-1 w-6 h-6 rounded-full flex items-center justify-center border-4 border-slate-900 bg-green-500"></div>
                <p className="text-xs text-slate-500 font-mono mb-1">
                  Há 2 min • Maria Clara
                </p>
                <p className="text-sm text-slate-300">
                  Forjou a Couraça da Justiça no Arsenal de Éfeso.
                </p>
              </div>
              <div className="relative pl-8">
                <div className="absolute left-0 top-1 w-6 h-6 rounded-full flex items-center justify-center border-4 border-slate-900 bg-blue-500"></div>
                <p className="text-xs text-slate-500 font-mono mb-1">
                  Há 5 min • Turma B
                </p>
                <p className="text-sm text-slate-300">
                  O Índice de Harmonia Global subiu 5 pontos coletivos.
                </p>
              </div>
            </div>
          </div>

          {/* MÓDULO DE IA COM O PAYWALL REFORÇADO (Upsell) */}
          <div className="lg:col-span-12 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden mt-4">
            <div className="flex justify-between items-center mb-6 relative z-10">
              <h2 className="text-xl font-bold text-white flex items-center">
                <Users className="w-5 h-5 mr-2 text-blue-500" /> Relatório
                Individual por Aluno (Deep AI)
              </h2>
            </div>

            <div className="space-y-4">
              {studentInsights.map((student) => (
                <div key={student.id} className="relative">
                  <div
                    className={`bg-slate-950 border border-slate-800/50 p-4 rounded-2xl flex flex-col md:flex-row md:items-center justify-between transition-colors ${
                      student.locked
                        ? "blur-[5px] opacity-60 select-none pointer-events-none"
                        : "hover:border-blue-500/30"
                    }`}
                  >
                    <div className="flex items-center space-x-4 mb-4 md:mb-0 w-1/4">
                      <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center font-bold text-slate-300">
                        {student.name.charAt(0)}
                      </div>
                      <div>
                        <h3 className="text-white font-bold">{student.name}</h3>
                        <div className="flex items-center mt-1">
                          <span
                            className={`text-[10px] uppercase font-black px-2 py-0.5 rounded-full ${
                              student.status === "Em Risco"
                                ? "bg-red-500/20 text-red-400"
                                : student.status === "Excelente"
                                ? "bg-green-500/20 text-green-400"
                                : "bg-yellow-500/20 text-yellow-400"
                            }`}
                          >
                            {student.status}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex-1 md:mx-8">
                      <p className="text-sm text-slate-400 italic">
                        "{student.insight}"
                      </p>
                    </div>
                    <div className="text-right mt-4 md:mt-0 w-1/6">
                      <p className="text-3xl font-black text-white">
                        {student.score}
                      </p>
                      <p className="text-xs text-slate-500 font-bold uppercase">
                        Score
                      </p>
                    </div>
                  </div>

                  {student.locked && (
                    <div className="absolute inset-0 z-10 flex items-center justify-center">
                      <div className="bg-slate-900/80 p-3 rounded-full border border-slate-700 shadow-xl backdrop-blur-sm">
                        <Lock className="w-6 h-6 text-amber-500" />
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Banner de Upsell Institucional */}
            <div className="absolute bottom-0 left-0 w-full p-10 bg-gradient-to-t from-slate-950 via-slate-950/95 to-transparent flex flex-col items-center justify-end z-20">
              <button
                onClick={() =>
                  alert(
                    "Simulação: A redirecionar para checkout B2B Stripe (Enterprise)."
                  )
                }
                className="group flex items-center px-10 py-5 bg-gradient-to-r from-amber-600 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-slate-950 rounded-full font-black text-xl transition-all shadow-[0_0_40px_rgba(245,158,11,0.4)] hover:scale-105"
              >
                <Crown className="w-7 h-7 mr-3" />
                DESBLOQUEAR PLANO ARQUITETO DIVINO
              </button>
              <p className="text-sm text-slate-400 mt-4 max-w-lg text-center">
                Acesso total aos relatórios cognitivos individuais, mapeamento
                ético e histórico de escolhas de todos os 30 alunos da turma.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// B2B Util Components
function SidebarLink({ icon: Icon, label, active, isPremium }) {
  return (
    <a
      href="#"
      className={`flex items-center justify-center md:justify-start px-4 py-3 rounded-xl transition-all relative group ${
        active
          ? "bg-blue-600/10 text-blue-500"
          : "text-slate-500 hover:bg-slate-800 hover:text-slate-300"
      }`}
    >
      <Icon className={`w-6 h-6 md:mr-3 ${active ? "text-blue-500" : ""}`} />
      <span className="hidden md:block font-semibold">{label}</span>
      {isPremium && (
        <Sparkles className="hidden md:block w-3 h-3 text-amber-500 absolute top-3 right-3 animate-pulse" />
      )}
    </a>
  );
}

function KPICard({ title, value, icon: Icon, color, bg, border }) {
  return (
    <div
      className={`bg-slate-900 border ${border} rounded-3xl p-6 shadow-lg flex items-center justify-between`}
    >
      <div>
        <p className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">
          {title}
        </p>
        <p className="text-4xl font-black text-white">{value}</p>
      </div>
      <div
        className={`w-14 h-14 ${bg} rounded-2xl flex items-center justify-center shrink-0 ml-4`}
      >
        <Icon className={`w-8 h-8 ${color}`} />
      </div>
    </div>
  );
}

function SkillBar({ label, percentage, color, icon: Icon }) {
  // Simples barra de progresso visual para a Matriz Cognitiva
  return (
    <div>
      <div className="flex justify-between items-end mb-2">
        <span className="flex items-center text-sm font-bold text-slate-300">
          {Icon && <Icon className="w-4 h-4 mr-2 text-slate-500" />} {label}
        </span>
        <span className="text-sm font-black text-white">{percentage}%</span>
      </div>
      <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
        <div
          className={`h-full ${color} transition-all duration-1000 ease-out`}
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
}

// Dummy Icon para fallback global
function Globe2(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" />
      <path d="M2 12h20" />
    </svg>
  );
}
