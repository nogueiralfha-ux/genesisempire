// src/supabaseClient.js
import { createClient } from "@supabase/supabase-js";

// Obtenha estas chaves no painel do Supabase em: Settings > API
const supabaseUrl = "https://ybgxktygferdaevskwyn.supabase.co";
const supabaseAnonKey = "sb_publishable_nNeDFLHRuPQ5FUpicY99_w_yMaZ8Iqt";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
